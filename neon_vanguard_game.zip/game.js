(() => {
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const arena = document.getElementById('arena');
  const $ = id => document.getElementById(id);
  const scoreEl=$('score'), waveEl=$('wave'), enemiesEl=$('enemies');
  const healthBar=$('healthBar'), healthText=$('healthText');
  const overlay=$('overlay'), startBtn=$('startBtn'), pauseBtn=$('pauseBtn');
  let W=0,H=0,last=0,running=false,paused=false,gameOver=false;
  let score=0,wave=1,health=100,spawnClock=0,shots=[],enemies=[],particles=[],keys={};
  let fireHeld=false, pointer={x:0,y:0,active:false}, joystick={x:0,y:0};
  const player={x:0,y:0,r:13,speed:245,angle:0,fire:0};
  const rand=(a,b)=>Math.random()*(b-a)+a;
  function resize(){const r=arena.getBoundingClientRect();const d=Math.min(devicePixelRatio||1,2);W=r.width;H=r.height;canvas.width=W*d;canvas.height=H*d;ctx.setTransform(d,0,0,d,0,0);if(!player.x){player.x=W/2;player.y=H/2}}
  window.addEventListener('resize',resize); resize();
  function updateHud(){scoreEl.textContent=String(score).padStart(6,'0');waveEl.textContent=String(wave).padStart(2,'0');enemiesEl.textContent=String(enemies.length).padStart(2,'0');healthBar.style.width=health+'%';healthText.textContent=Math.ceil(health)+'%';healthBar.style.background=health<30?'linear-gradient(90deg,#ff456f,#ff9b6b)':'linear-gradient(90deg,#36e9b0,#b6ff70)'}
  function reset(){score=0;wave=1;health=100;shots=[];enemies=[];particles=[];spawnClock=0;player.x=W/2;player.y=H/2;player.fire=0;gameOver=false;updateHud()}
  function spawnEnemy(){const side=Math.floor(Math.random()*4);let x=side===0?-25:side===1?W+25:rand(0,W),y=side===2?-25:side===3?H+25:rand(0,H);const type=Math.random()<.23?'heavy':'scout';enemies.push({x,y,r:type==='heavy'?19:13,hp:type==='heavy'?3:1,max:type==='heavy'?3:1,speed:(type==='heavy'?45:rand(65,90))+wave*4,type,hit:0})}
  function burst(x,y,color,n=9){for(let i=0;i<n;i++){const a=rand(0,Math.PI*2),s=rand(35,180);particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.2,.55),max:.55,color})}}
  function shoot(){if(player.fire>0)return;player.fire=.16;const a=player.angle;shots.push({x:player.x+Math.cos(a)*18,y:player.y+Math.sin(a)*18,vx:Math.cos(a)*610,vy:Math.sin(a)*610,life:.85});burst(player.x+Math.cos(a)*18,player.y+Math.sin(a)*18,'#6efff4',3)}
  function start(){reset();running=true;paused=false;overlay.classList.add('hidden');pauseBtn.textContent='Ⅱ إيقاف مؤقت';last=performance.now();requestAnimationFrame(loop)}
  function end(){running=false;gameOver=true;$('overlayTitle').textContent='انتهت المهمة';$('overlayText').textContent=`حققت ${score} نقطة ووصلت إلى الموجة ${wave}. هل تريد المحاولة مرة أخرى؟`;startBtn.textContent='إعادة المحاولة';overlay.classList.remove('hidden')}
  function loop(t){if(!running)return;const dt=Math.min((t-last)/1000,.033);last=t;if(!paused)update(dt);draw();requestAnimationFrame(loop)}
  function update(dt){
    let mx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+joystick.x;
    let my=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0)+joystick.y;
    const mag=Math.hypot(mx,my)||1;if(Math.hypot(mx,my)>1){mx/=mag;my/=mag}
    player.x=Math.max(18,Math.min(W-18,player.x+mx*player.speed*dt));player.y=Math.max(18,Math.min(H-18,player.y+my*player.speed*dt));
    if(pointer.active){player.angle=Math.atan2(pointer.y-player.y,pointer.x-player.x)}else if(enemies.length){const e=enemies.reduce((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)<Math.hypot(b.x-player.x,b.y-player.y)?a:b);player.angle=Math.atan2(e.y-player.y,e.x-player.x)}
    player.fire=Math.max(0,player.fire-dt);if(fireHeld||keys[' '])shoot();
    spawnClock-=dt;if(spawnClock<=0&&enemies.length<Math.min(5+wave*2,22)){spawnEnemy();spawnClock=Math.max(.28,1.15-wave*.055)}
    if(score>=wave*180){wave++;burst(W/2,H/2,'#ffcf68',24)}
    for(const s of shots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt}
    shots=shots.filter(s=>s.life>0&&s.x>-30&&s.x<W+30&&s.y>-30&&s.y<H+30);
    for(const e of enemies){const a=Math.atan2(player.y-e.y,player.x-e.x);e.x+=Math.cos(a)*e.speed*dt;e.y+=Math.sin(a)*e.speed*dt;e.hit=Math.max(0,e.hit-dt);if(Math.hypot(e.x-player.x,e.y-player.y)<e.r+player.r){health-= (e.type==='heavy'?25:14)*dt;if(health<=0){health=0;updateHud();end();return}}}
    for(const s of shots){for(const e of enemies){if(e.hp>0&&Math.hypot(s.x-e.x,s.y-e.y)<e.r+4){e.hp--;s.life=0;e.hit=.08;burst(s.x,s.y,'#56fff0',4);if(e.hp<=0){score+=e.type==='heavy'?35:15;burst(e.x,e.y,e.type==='heavy'?'#ff4e91':'#51fff0',15)}break}}}
    enemies=enemies.filter(e=>e.hp>0);
    for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.96;p.vy*=.96;p.life-=dt}
    particles=particles.filter(p=>p.life>0);updateHud();
  }
  function draw(){
    ctx.clearRect(0,0,W,H);ctx.fillStyle='#081226';ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='#193253';ctx.lineWidth=1;for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
    ctx.strokeStyle='#2b6a7c55';ctx.lineWidth=1;ctx.beginPath();ctx.arc(W/2,H/2,Math.min(W,H)*.27,0,Math.PI*2);ctx.stroke();
    for(const p of particles){ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.fillRect(p.x,p.y,3,3)}ctx.globalAlpha=1;
    for(const s of shots){ctx.save();ctx.shadowBlur=15;ctx.shadowColor='#48fff0';ctx.fillStyle='#d8fffb';ctx.beginPath();ctx.arc(s.x,s.y,3,0,Math.PI*2);ctx.fill();ctx.restore()}
    for(const e of enemies){ctx.save();ctx.translate(e.x,e.y);ctx.rotate(Math.atan2(player.y-e.y,player.x-e.x));ctx.shadowBlur=18;ctx.shadowColor=e.type==='heavy'?'#ff4e91':'#ffb44e';ctx.fillStyle=e.hit?'#fff':(e.type==='heavy'?'#a92d68':'#a66a2b');ctx.strokeStyle=e.type==='heavy'?'#ff6ca9':'#ffd078';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(e.r+5,0);ctx.lineTo(0,-e.r);ctx.lineTo(-e.r,0);ctx.lineTo(0,e.r);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#fff';ctx.fillRect(-e.r,-e.r-8,e.r*2,3);ctx.fillStyle='#ff4e91';ctx.fillRect(-e.r,-e.r-8,e.r*2*(e.hp/e.max),3);ctx.restore()}
    ctx.save();ctx.translate(player.x,player.y);ctx.rotate(player.angle);ctx.shadowBlur=22;ctx.shadowColor='#42f5e9';ctx.fillStyle='#42f5e9';ctx.strokeStyle='#d5fffb';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-11);ctx.lineTo(-6,0);ctx.lineTo(-11,11);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#eaffff';ctx.fillRect(0,-3,19,6);ctx.restore();
    ctx.fillStyle='#42f5e9';ctx.globalAlpha=.45;ctx.beginPath();ctx.arc(player.x,player.y,25,0,Math.PI*2);ctx.strokeStyle='#42f5e9';ctx.stroke();ctx.globalAlpha=1;
  }
  window.addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(e.key.toLowerCase()))e.preventDefault()});
  window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
  canvas.addEventListener('pointermove',e=>{const r=canvas.getBoundingClientRect();pointer={x:e.clientX-r.left,y:e.clientY-r.top,active:true}});
  canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){fireHeld=true;canvas.setPointerCapture(e.pointerId)}});
  window.addEventListener('pointerup',()=>fireHeld=false);
  $('fireButton').addEventListener('pointerdown',e=>{e.preventDefault();fireHeld=true});$('fireButton').addEventListener('pointerup',()=>fireHeld=false);$('fireButton').addEventListener('pointercancel',()=>fireHeld=false);
  const joy=$('joystick'),stick=$('stick');let joyId=null;
  joy.addEventListener('pointerdown',e=>{joyId=e.pointerId;joy.setPointerCapture(joyId);moveJoy(e)});
  joy.addEventListener('pointermove',e=>{if(e.pointerId===joyId)moveJoy(e)});
  function moveJoy(e){const r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),len=Math.hypot(dx,dy),scale=Math.min(1,38/(len||1));joystick.x=dx*scale/38;joystick.y=dy*scale/38;stick.style.transform=`translate(${dx*scale}px,${dy*scale}px)`}
  function endJoy(){joyId=null;joystick={x:0,y:0};stick.style.transform='translate(0,0)'}
  joy.addEventListener('pointerup',endJoy);joy.addEventListener('pointercancel',endJoy);
  startBtn.addEventListener('click',start);
  pauseBtn.addEventListener('click',()=>{if(!running)return;paused=!paused;pauseBtn.textContent=paused?'▶ متابعة':'Ⅱ إيقاف مؤقت';if(paused){$('overlayTitle').textContent='اللعبة متوقفة';$('overlayText').textContent='خذ وقتك، ثم تابع المعركة عندما تكون مستعداً.';startBtn.textContent='متابعة';overlay.classList.remove('hidden');startBtn.onclick=()=>{overlay.classList.add('hidden');paused=false;pauseBtn.textContent='Ⅱ إيقاف مؤقت';startBtn.onclick=start}}});
  updateHud();draw();
})();